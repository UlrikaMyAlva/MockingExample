package com.example;

public interface BankService {
	void pay(String id, double amount);

}
